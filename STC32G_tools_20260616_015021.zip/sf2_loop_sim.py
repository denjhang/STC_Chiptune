#!/usr/bin/env python3
"""PC 仿真 MCU SF2 ADPCM 解码 + loop 回绕

模拟 MCU 完整路径:
  公式编码器编码 -> MCU 硬编码表解码 -> addr > loop_end 回绕 -> >>5 衰减
"""

import struct, os, wave, json

WAV_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'adpcm_wav')
OUT_DIR = os.path.join(WAV_DIR, 'loop_test')
os.makedirs(OUT_DIR, exist_ok=True)

SF2_ROOT = 'D:/working/vscode-projects/Reference_Project/STC-MCU/sf2_extract'
TARGET_RATE = 17640

# jedi_table: 直接复制自 adpcm.c 的硬编码表 (784 s16, 49 step * 16 nib)
# 确保编码器和解码器(C MCU)完全一致
JEDI_FLAT = [
     2,     6,    10,    14,    18,    22,    26,    30,    -2,    -6,   -10,   -14,   -18,   -22,   -26,   -30,
     2,     6,    10,    14,    19,    23,    27,    31,    -2,    -6,   -10,   -14,   -19,   -23,   -27,   -31,
     2,     7,    11,    16,    21,    26,    30,    35,    -2,    -7,   -11,   -16,   -21,   -26,   -30,  -35,
     2,     7,    13,    18,    23,    28,    34,    39,    -2,    -7,   -13,   -18,   -23,   -28,  -34,  -39,
     2,     8,    14,    20,    25,    31,    37, 43,    -2,    -8,   -14,   -20,   -25,  -31,   -37,  -43,
     3,     9,    15,    21,    28,    34, 40, 46,    -3,    -9,   -15,   -21,   -28,   -34,  -40,  -46,
     3,    10,    17,   24,    31,    38,   45,   52,    -3,   -10,   -17,   -24,   -31,   -38,  -45,  -52,
     3,    11,    19,    27,    34,    42,   50,    58,    -3,   -11,  -19,   -27,   -34,   -42,  -50,  -58,
     4,    12,    21,    29,    38,   46,    55,    63,    -4,   -12,  -21,   -29,   -38,   -46,  -55,  -63,
     4,    13,    23,    32,    41,    50,   60,    69,    -4,   -13,  -23,   -32,   -41,   -50,  -60,  -69,
     5,    15,    25,    35,   46,    56,   66, 76,    -5,   -15,   -25,   -35,   -46,  -56,  -66,  -76,
     5,    16,    28,    39,    50, 61, 73, 84,    -5,   -16,  -28,  -39,  -50,  -61,  -73,  -84,
     6,    18,    31,    43,    56,    68,    81, 93,    -6,   -18,  -31,  -43,  -56,  -68,  -81,  -93,
     6,    20,    34,    48,    61,    75,    89,   103, -6,   -20,  -34,  -48,  -61,  -75,  -89,  -103,
     7,    22,    37,    52,    67,    82,    97,   112, -7,  -22,  -37,  -52,  -67,  -82,  -97,  -112,
     8,    24,    41,    57,    74,    90, 107,  123, -8,   -24,  -41,  -57,  -74,  -90, -107,  -123,
     9,    27,    45,    63,    82,   100,  118,  136, -9,   -27,  -45,  -63,  -82,  -100, -118, -136,
    10,    30,    50,    70,    90,   110,  130,  150, -10,  -30,  -50,  -70,  -90,  -110,  -130, -150,
    11,    33,    55,    77,    99,   121,  143,  165, -11,  -33,  -55,  -77,  -99,  -121,  -143, -165,
    12,    36,    60,    84,   109,  133,  157, 181, -12,  -36,  -60,  -84,  -109,  -133,  -157, -181,
    13,    40,    66,    93,   120, 147, 173,  200, -13,  -40,  -66,  -93,  -120,  -147, -173, -200,
    14,    44,    73,   103,  132, 162, 191, 221, -14,  -44,  -73,  -103, -132, -162, -191, -221,
    16,    48,    81,   113,  146, 178,  211, 243, -16,  -48,  -81,  -113,  -146, -178, -211, -243,
    17,    53,    89,   125,  160, 196, 232, 268, -17,  -53,  -89,  -125, -160, -196, -232, -268,
    19,    58,    98,   137,  176,  215,  255, 294, -19,  -58,  -98,  -137,  -176, -215, -255, -294,
    21,    64,   108,   151, 194, 237,  281, 324, -21,  -64,  -108,  -151,  -194, -237, -281, -324,
    23,    71,   118,   166, 213, 261, 308, 356, -23,  -71,  -118,  -166,  -213, -261, -308, -356,
    26,    78,   130,   182, 235, 287, 339, 391, -26,  -78,  -130,  -182, -235, -287, -339, -391,
    28,    86,   143,   201, 258, 316, 373, 431, -28,  -86,  -143,  -201, -258, -316, -373, -431,
    31,    94,   158,   221, 284, 347, 411, 474, -31,  -94,  -158,  -221, -284, -347, -411, -474,
    34,   104,   174,   244, 313, 383, 453, 523, -34,  -104, -174,  -244, -313, -383, -453, -523,
    38,   115,   191,   268, 345, 422, 498, 575, -38,  -115, -191,  -268, -345, -422, -498, -575,
    42,   126,   210,   294, 379, 463, 547, 631, -42,  -126,  -210,  -294, -379, -463, -547, -631,
    46,   139,   231,   324, 417, 510, 602, 695, -46,  -139,  -231,  -324, -417, -510, -602, -695,
    51,   153,   255,   357, 459, 561, 663, 765, -51,  -153,  -255,  -357, -459, -561, -663, -765,
    56,   168,   280,   392, 505, 617, 729, 841, -56,  -168,  -280,  -392, -505,  -617, -729, -841,
    61,   185,   308,   432, 555, 679, 802, 926, -61,  -185,  -308,  -432, -555, -679, -802, -926,
    68,   204,   340,   476, 612, 748, 884,1020, -68,  -204,  -340,  -476, -612, -748, -884, -1020,
    74,   224,   373,   523, 672, 822, 971,1121, -74,  -224,  -373,  -523,  -672, -822, -971, -1121,
    82,   246,   411,   575, 740, 904,1069,1233, -82,  -246,  -411,  -575,  -740, -904, -1069, -1233,
    90,   271,   452,   633, 814, 995,1176,1357, -90,  -271,  -452,  -633,  -814,  -995, -1176, -1357,
    99,   298,   497,   696, 895,1094,1293,1492, -99,  -298,  -497,  -696,  -895, -1094, -1293, -1492,
   109,   328,   547,   766, 985,1204,1423,1642, -109, -328,  -547,  -766,  -985, -1204, -1423, -1642,
   120,   361,   601,   842,1083,1324,1564,1805, -120, -361,  -601,  -842, -1083, -1324, -1564, -1805,
   132,   397,   662,   927,1192,1457,1722,1987, -132, -397,  -662,  -927, -1192, -1457, -1722, -1987,
   145,   437,   728,  1020,1311,1603,1894,2186, -145, -437,  -728, -1020, -1311, -1603, -1894, -2186,
   160,   480,   801, 1121,1442,1762,2083,2403, -160, -480,  -801, -1121, -1442, -1762, -2083, -2403,
   176,   529,   881, 1234,1587,1940,2292,2645, -176, -529,  -881, -1234, -1587, -1940, -2292, -2645,
   194,   582,   970, 1358,1746,2134,2522,2910, -194, -582,  -970, -1358, -1746, -2134, -2522, -2910,
]
STEP_INC = [-16,-16,-16,-16,32,80,112,144]

INSTRUMENTS = [
    ('01_piano.wav',      'snes_unofficial', 35, 'Piano'),
    ('02_slapbass.wav',   'snes_unofficial', 34, 'SlapBass'),
    ('03_shakuhachi.wav', 'microgm',         211, 'Shakuhachi'),
    ('04_oboe.wav',       'snes_unofficial', 102, 'Oboe'),
    ('05_trumpet.wav',    'snes_unofficial', 45, 'Trumpet'),
    ('06_blow.wav',       'microgm',         207, 'Blow'),
    ('07_oboe2.wav',      'snes_unofficial', 69, 'Oboe2'),
    ('08_strings.wav',    'snes_unofficial', 50, 'Strings'),
    ('09_harp.wav',       'snes_unofficial', 90, 'Harp'),
    ('10_guitar.wav',     'snes_unofficial', 91, 'Guitar'),
]


def adpcm_encode(pcm, snap_nibble=-1):
    nibbles = []
    acc = 0
    step_idx = 0
    for i, s in enumerate(pcm):
        if s > 2047: s = 2047
        if s < -2048: s = -2048
        best = 0
        bd = abs(s - acc)
        for n in range(16):
            d = JEDI_FLAT[step_idx + n]
            t = acc + d
            t &= 0xFFF
            if t & 0x800: t |= ~0xFFF
            if abs(s - t) < bd:
                bd = abs(s - t)
                best = n
        d = JEDI_FLAT[step_idx + best]
        acc += d
        acc &= 0xFFF
        if acc & 0x800: acc |= ~0xFFF
        step_idx += STEP_INC[best & 7]
        if step_idx < 0: step_idx = 0
        if step_idx > 768: step_idx = 768
        nibbles.append(best)
    rom = bytearray()
    for i in range(0, len(nibbles), 2):
        hi = nibbles[i]
        lo = nibbles[i + 1] if i + 1 < len(nibbles) else 0
        rom.append((hi << 4) | lo)
    rom = bytes(rom)
    # 用硬编码表解码到 snap_nibble 处记录状态
    snap = None
    if snap_nibble >= 0:
        dacc = 0; dstep = 0
        for i in range(min(snap_nibble + 1, len(nibbles))):
            byte_val = rom[i >> 1]
            nib = (byte_val >> 4) & 0x0F if not (i & 1) else byte_val & 0x0F
            d = JEDI_FLAT[dstep + nib]
            dacc += d; dacc &= 0xFFF
            if dacc & 0x800: dacc |= ~0xFFF
            dstep += STEP_INC[nib & 7]
            if dstep < 0: dstep = 0
            if dstep > 768: dstep = 768
            if i == snap_nibble:
                snap = (dacc & 0xFFF, dstep)
    return rom, len(nibbles), snap


def mcu_decode(rom_bytes, start_nib, loop_start, loop_end, n_samples,
               loop_acc=0, loop_step=0):
    """模拟 MCU 解码: 硬编码表 + addr > loop_end 回绕 + acc/step 重置"""
    samples = []
    addr = start_nib
    acc = 0
    step = 0
    for i in range(n_samples):
        byte_val = rom_bytes[addr >> 1]
        if addr & 1:
            nib = byte_val & 0x0F
        else:
            nib = (byte_val >> 4) & 0x0F
        d = JEDI_FLAT[step + nib]
        acc += d
        acc &= 0xFFF
        if acc & 0x800: acc |= ~0xFFF
        samples.append(acc)
        step += STEP_INC[nib & 7]
        if step < 0: step = 0
        if step > 768: step = 768
        addr += 1
        if addr > loop_end:
            addr = loop_start
            acc = loop_acc & 0xFFF
            if acc & 0x800: acc |= ~0xFFF
            step = loop_step
    return samples


def main():
    dur = 3.0
    dur_samples = int(dur * TARGET_RATE)

    for wav_name, sf2_src, sf2_id, display in INSTRUMENTS:
        meta_path = os.path.join(SF2_ROOT, sf2_src, 'sf2_mapping.json')
        with open(meta_path) as f:
            data = json.load(f)
        meta = data['samples'][str(sf2_id)]
        ls = meta['loop_start']
        le = meta['loop_end']

        with wave.open(os.path.join(WAV_DIR, wav_name), 'r') as w:
            raw = w.readframes(w.getnframes())
        pcm16 = list(struct.unpack('<%dh' % (len(raw) // 2), raw))

        # 归一化到 12-bit
        peak = max(abs(s) for s in pcm16)
        scale = 2047.0 / peak if peak > 0 else 1.0
        normalized = [int(s * scale) for s in pcm16]

        rom, nib_count, snap = adpcm_encode(normalized, snap_nibble=ls)
        loop_acc = snap[0] if snap else 0
        loop_step = snap[1] if snap else 0
        if loop_acc & 0x800: loop_acc = loop_acc - 0x1000

        # MCU 解码 (含 loop + acc/step reset)
        decoded = mcu_decode(rom, 0, ls, le, dur_samples, loop_acc, loop_step)

        # >>5 衰减 + vol=31
        out_16 = [max(-32768, min(32767, s * 31 >> 5)) for s in decoded]

        out_path = os.path.join(OUT_DIR, f'mcu_{os.path.splitext(wav_name)[0]}.wav')
        with wave.open(out_path, 'w') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(TARGET_RATE)
            wf.writeframes(struct.pack('<%dh' % len(out_16), *out_16))

        # loop 接缝检测: 第一次回绕点
        wrap_idx = le + 1  # 播放 le 后 addr++ 变 le+1, 触发回绕到 ls
        # 但注意: start_nib=0, ls=1915, 所以 loop 在 decoded 中从 ls 开始
        # 第一次回绕发生在第 le+1 个采样之后, 即 decoded[le] 是 loop_end 的采样
        # decoded[le+1] 是回绕后 loop_start 的采样
        if le + 1 < len(decoded):
            print(f'{display:12s} ls={ls:5d} le={le:5d} '
                  f'wrap: [{le}]={decoded[le]} -> [{le+1}]={decoded[le+1]} '
                  f'diff={abs(decoded[le] - decoded[le+1])}')
        print(f'  -> {out_path}')

    print('\nDone.')


if __name__ == '__main__':
    main()
